# A Library for Modular Data Pipelines

- This library builds off Pandas and automates portions of data cleaning and API integration for several platforms.
