# E:\Projects\ournetwork\pipeline\setup.py
from setuptools import setup, find_packages

setup(
    name="pipeline",
    version="0.1",
    packages=find_packages(),  # Automatically finds subpackages
    install_requires=[
        "pandas",
        "numpy",
        "plotly",
        "kaleido",
        "pyairtable",
        "python-dotenv",
        "google-analytics-data",
        "google-auth-oauthlib",
        "google-api-python-client"
    ],
    include_package_data=True,
    zip_safe=False,
)
